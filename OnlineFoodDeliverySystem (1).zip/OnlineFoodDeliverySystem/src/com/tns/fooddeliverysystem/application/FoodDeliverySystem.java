package com.tns.fooddeliverysystem.application;

import com.tns.fooddeliverysystem.entities.*;
import com.tns.fooddeliverysystem.services.*;

import java.util.*;

public class FoodDeliverySystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int mainChoice;

        do {
            System.out.println("\n1. Admin Menu\n2. Customer Menu\n3. Exit");
            System.out.print("Choose an option: ");
            mainChoice = sc.nextInt();

            switch (mainChoice) {
                case 1 -> runAdminMenu(sc);
                case 2 -> runCustomerMenu(sc);
                case 3 -> System.out.println("Thanks for using the system!");
                default -> System.out.println("Invalid choice.");
            }
        } while (mainChoice != 3);
    }

    static void runAdminMenu(Scanner sc) {
        int choice;
        do {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Add Restaurant");
            System.out.println("2. Add Food Item");
            System.out.println("3. Remove Food Item");
            System.out.println("4. View Restaurants");
            System.out.println("5. View Orders");
            System.out.println("6. Add Delivery Person");
            System.out.println("7. Assign Delivery Person to Order");
            System.out.println("8. Exit");
            System.out.print("Choose: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> RestaurantService.addRestaurant(sc);
                case 2 -> RestaurantService.addFoodItemToRestaurant(sc);
                case 3 -> RestaurantService.removeFoodItemFromRestaurant(sc);
                case 4 -> RestaurantService.viewRestaurants();
                case 5 -> OrderService.viewAllOrders();
                case 6 -> DeliveryService.addDeliveryPerson(sc);
                case 7 -> OrderService.assignDeliveryPersonToOrder(sc);
                case 8 -> System.out.println("Exiting Admin...");
                default -> System.out.println("Invalid.");
            }
        } while (choice != 8);
    }

    static void runCustomerMenu(Scanner sc) {
        int choice;
        do {
            System.out.println("\n--- Customer Menu ---");
            System.out.println("1. Add Customer");
            System.out.println("2. View Menu");
            System.out.println("3. Add Food to Cart");
            System.out.println("4. View Cart");
            System.out.println("5. Place Order");
            System.out.println("6. View Orders");
            System.out.println("7. Exit");
            System.out.print("Choose: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> CustomerService.addCustomer(sc);
                case 2 -> RestaurantService.viewRestaurants();
                case 3 -> CustomerService.addToCart(sc);
                case 4 -> CustomerService.viewCart(sc);
                case 5 -> {
                    System.out.print("Enter Customer ID: ");
                    int cid = sc.nextInt();
                    Customer cust = CustomerService.getCustomer(cid);
                    if (cust != null)
                        OrderService.placeOrder(cust);
                    else
                        System.out.println("Customer not found.");
                }
                case 6 -> {
                    System.out.print("Enter Customer ID: ");
                    int cid = sc.nextInt();
                    OrderService.viewCustomerOrders(cid);
                }

                case 7 -> System.out.println("Exiting Customer...");
                default -> System.out.println("Invalid.");
            }
        } while (choice != 7);
    }

}
