package com.tns.fooddeliverysystem.services;

import com.tns.fooddeliverysystem.entities.DeliveryPerson;

import java.util.*;

public class DeliveryService {
    private static Map<Integer, DeliveryPerson> deliveryPeople = new HashMap<>();

    public static void addDeliveryPerson(Scanner sc) {
        System.out.print("Enter Delivery Person ID: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Contact Number: ");
        long contact = sc.nextLong();

        deliveryPeople.put(id, new DeliveryPerson(id, name, contact));
        System.out.println("Delivery person added successfully!");
    }

    public static DeliveryPerson getDeliveryPerson(int id) {
        return deliveryPeople.get(id);
    }
}
