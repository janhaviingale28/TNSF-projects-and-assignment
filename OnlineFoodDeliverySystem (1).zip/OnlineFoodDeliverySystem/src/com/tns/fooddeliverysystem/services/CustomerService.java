package com.tns.fooddeliverysystem.services;

import com.tns.fooddeliverysystem.entities.*;

import java.util.*;

public class CustomerService {
    private static Map<Integer, Customer> customers = new HashMap<>();

    public static void addCustomer(Scanner sc) {
        System.out.print("Enter Customer ID: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Contact No: ");
        long contact = sc.nextLong();
        customers.put(id, new Customer(id, name, contact));
        System.out.println("Customer created successfully!");
    }

    public static Customer getCustomer(int id) {
        return customers.get(id);
    }

    public static void addToCart(Scanner sc) {
        System.out.print("Enter Customer ID: ");
        int cid = sc.nextInt();
        Customer cust = customers.get(cid);
        if (cust == null) {
            System.out.println("Customer not found.");
            return;
        }

        System.out.print("Enter Restaurant ID: ");
        int rid = sc.nextInt();
        Restaurant r = RestaurantService.getAllRestaurants().get(rid);
        if (r == null) {
            System.out.println("Restaurant not found.");
            return;
        }

        System.out.print("Enter Food Item ID: ");
        int fid = sc.nextInt();
        System.out.print("Enter Quantity: ");
        int qty = sc.nextInt();

        FoodItem item = r.getMenu().stream().filter(f -> f.getId() == fid).findFirst().orElse(null);
        if (item != null) {
            cust.getCart().addItem(item, qty);
            System.out.println("Item added to cart!");
        } else {
            System.out.println("Food item not found.");
        }
    }

    public static void viewCart(Scanner sc) {
        System.out.print("Enter Customer ID: ");
        int cid = sc.nextInt();
        Customer cust = customers.get(cid);
        if (cust != null)
            System.out.println(cust.getCart());
        else
            System.out.println("Customer not found.");
    }
}
