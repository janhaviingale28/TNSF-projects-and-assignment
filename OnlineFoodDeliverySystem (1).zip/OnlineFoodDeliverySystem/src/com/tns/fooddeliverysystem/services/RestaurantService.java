package com.tns.fooddeliverysystem.services;

import com.tns.fooddeliverysystem.entities.*;

import java.util.*;

public class RestaurantService {
    private static Map<Integer, Restaurant> restaurants = new HashMap<>();

    public static void addRestaurant(Scanner sc) {
        System.out.print("Enter Restaurant ID: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Restaurant Name: ");
        String name = sc.nextLine();
        restaurants.put(id, new Restaurant(id, name));
        System.out.println("Restaurant added successfully!");
    }

    public static void addFoodItemToRestaurant(Scanner sc) {
        System.out.print("Enter Restaurant ID: ");
        int rid = sc.nextInt();
        Restaurant r = restaurants.get(rid);
        if (r != null) {
            System.out.print("Enter Food Item ID: ");
            int fid = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Food Name: ");
            String fname = sc.nextLine();
            System.out.print("Enter Price: ");
            double price = sc.nextDouble();
            r.addFoodItem(new FoodItem(fid, fname, price));
            System.out.println("Food item added successfully!");
        } else {
            System.out.println("Restaurant not found.");
        }
    }

    public static void removeFoodItemFromRestaurant(Scanner sc) {
        System.out.print("Enter Restaurant ID: ");
        int rid = sc.nextInt();
        Restaurant r = restaurants.get(rid);
        if (r != null) {
            System.out.print("Enter Food Item ID to remove: ");
            int fid = sc.nextInt();
            r.removeFoodItem(fid);
            System.out.println("Item removed.");
        } else {
            System.out.println("Restaurant not found.");
        }
    }

    public static void viewRestaurants() {
        for (Restaurant r : restaurants.values()) {
            System.out.println("Restaurant ID: " + r.getId() + ", Name: " + r.getName());
            for (FoodItem f : r.getMenu()) {
                System.out.println("- ID: " + f.getId() + ", " + f.getName() + ", ₹" + f.getPrice());
            }
        }
    }

    public static Map<Integer, Restaurant> getAllRestaurants() {
        return restaurants;
    }
}
