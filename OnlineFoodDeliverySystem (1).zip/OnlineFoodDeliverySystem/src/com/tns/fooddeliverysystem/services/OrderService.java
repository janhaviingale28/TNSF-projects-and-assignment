package com.tns.fooddeliverysystem.services;

import com.tns.fooddeliverysystem.entities.*;

import java.util.*;

public class OrderService {
    private static Map<Integer, Order> orders = new HashMap<>();
    private static int orderIdCounter = 1;

    // Method to place an order for a given customer
    public static void placeOrder(Customer customer) {
        Order order = new Order(orderIdCounter++, customer);
        orders.put(order.getOrderId(), order);
        System.out.println("Order placed successfully! Your order ID is: " + order.getOrderId());
    }

    // Method to assign a delivery person to a specific order
    public static void assignDeliveryPersonToOrder(Scanner sc) {
        System.out.print("Enter Order ID: ");
        int oid = sc.nextInt();
        Order order = orders.get(oid);
        if (order == null) {
            System.out.println("Order not found.");
            return;
        }

        System.out.print("Enter Delivery Person ID: ");
        int did = sc.nextInt();
        DeliveryPerson dp = DeliveryService.getDeliveryPerson(did);
        if (dp == null) {
            System.out.println("Delivery person not found.");
            return;
        }

        order.assignDeliveryPerson(dp);
        System.out.println("Delivery person assigned successfully!");
    }

    // Method to view all orders (for Admin)
    public static void viewAllOrders() {
        if (orders.isEmpty()) {
            System.out.println("No orders found.");
            return;
        }

        for (Order order : orders.values()) {
            System.out.println(order);
        }
    }

    // Method to view orders placed by a specific customer (for Customer)
    public static void viewCustomerOrders(int customerId) {
        boolean found = false;
        for (Order order : orders.values()) {
            if (order.getCustomer().getUserId() == customerId) {
                System.out.println(order);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No orders found for this customer.");
        }
    }
}
