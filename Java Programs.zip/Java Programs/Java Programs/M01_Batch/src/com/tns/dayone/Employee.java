package com.tns.dayone;

public class Employee {

	public static void main(String[] args) {
		
		String name = "Karthik";
		int age = 25 ;
		double salary = 24000;
		
		System.out.println("Employee name: "+name);
		System.out.println(age);
		System.out.println(salary);

	}

}
