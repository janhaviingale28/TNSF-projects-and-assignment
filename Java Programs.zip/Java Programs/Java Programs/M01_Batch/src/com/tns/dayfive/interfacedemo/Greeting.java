package com.tns.dayfive.interfacedemo;


@FunctionalInterface
public interface Greeting {
	
	//declaration

	public String greet();

	
}
